enum RideState {
    Accepted,
    Denied,
    Pending
}
