public class User extends Person {
    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    private double balance;

    public void requestRide(String src, String des, double price) {

    }

    public void rateDriver() {

    }

    public void driverData() {

    }

}
