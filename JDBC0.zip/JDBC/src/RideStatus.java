public enum RideStatus {
    Accepted,
    Denied,
    Pending
}
